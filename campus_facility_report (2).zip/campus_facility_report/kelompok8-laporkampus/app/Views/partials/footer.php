<footer class="footer">
    <div class="container">
        <p>
            &copy; <?= date('Y') ?> FasilitasKampusKu - Sistem Laporan Kerusakan Fasilitas Kampus
        </p>
        <p>Dikembangkan dengan ❤️ untuk kemudahan pelaporan fasilitas kampus</p>
    </div>
</footer>